import os
from pymongo import MongoClient

class AnimalShelter:
    def __init__(self):
        """
        Constructor to initialize the AnimalShelter object.
        Reads MongoDB connection details from environment variables.
        """
        try:
            # Read environment variables for MongoDB connection
            mongo_host = os.getenv("MONGO_HOST", "localhost")
            mongo_port = int(os.getenv("MONGO_PORT", 27017))
            mongo_user = os.getenv("MONGO_USER", "")
            mongo_pass = os.getenv("MONGO_PASS", "")
            
            # Connect to MongoDB using environment variables
            self.client = MongoClient(
                host=mongo_host,
                port=mongo_port,
                username=mongo_user,
                password=mongo_pass
            )
            
            # Connect to the AAC database and animals collection
            self.database = self.client["AAC"]
            self.collection = self.database["animals"]
        except Exception as e:
            raise Exception(f"Could not connect to MongoDB: {e}")

    def create(self, data):
        """
        Inserts a document into the specified MongoDB collection.
        :param data: A dictionary containing the document to insert.
        :return: True if the insertion is successful, False otherwise.
        """
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Error inserting data: {e}")
                return False
        else:
            raise ValueError("Data must not be empty.")

    def read(self, query):
    	"""
    	Reads documents from MongoDB based on a query and returns clean records as a list of 	dictionaries.
    	"""
    	try:
        	results = list(self.collection.find(query, {"_id": 0}))

        	# Debug: Print raw keys
        	if results:
            		print("Raw Keys in MongoDB Document:", list(results[0].keys()))

        	# Clean keys: strip spaces, remove extra quotes
        	cleaned_results = []
        	for record in results:
            		cleaned_record = {key.strip().replace('"', ''): value for key, value in record.items()}
            		cleaned_results.append(cleaned_record)

        	return cleaned_results
    	except Exception as e:
        	print(f"Error fetching data: {e}")
        	return []








    def update(self, query, updates):
        """
        Updates documents in the MongoDB collection.
        :param query: A dictionary to match documents.
        :param updates: A dictionary containing the fields to update.
        :return: The number of documents updated.
        """
        if query and updates:
            try:
                result = self.collection.update_many(query, {'$set': updates})
                return result.modified_count
            except Exception as e:
                print(f"Error updating data: {e}")
                return 0
        else:
            raise ValueError("Query and updates must not be empty.")

    def delete(self, query):
        """
        Deletes documents from the MongoDB collection.
        :param query: A dictionary to match documents.
        :return: The number of documents deleted.
        """
        if query:
            try:
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting data: {e}")
                return 0
        else:
            raise ValueError("Query must not be empty.")

